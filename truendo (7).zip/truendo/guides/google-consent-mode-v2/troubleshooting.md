---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: Troubleshooting
id: DQP-1PG8-04L-ZEK
slug: troubleshooting
isVisible: true
lastUpdated: '2024-07-05 12:20:37'
---
## Troubleshooting Consent Mode V2 and TRUENDO

In this section we will cover some of the most common issues that can happen and how to solve them. If you are experiencing anything not covered here please contact our support viua the chat bubble or by email at support@truendo.com

<br />

I see 'collect' requests with gcs parameters before consent but I am trying to use Basic consent mode.

Please follow steps from or steps from carefully ensure

If using GTM:

Check the TRUENDO tag is configured and added to the container

Make sure the correct container is integrated

check that you have set the tags to check for additional consent with the relevant truendo tags and triggers

<br />

<br />

<br />

<br />