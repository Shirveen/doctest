---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: Index
id: SAL-PF6J-EMH-GQE
slug: index
isVisible: true
lastUpdated: '2024-06-19 08:43:11'
---
# Google Consent Mode and TRUENDO

The contents of this chapter are for those who use Google Consent Mode in GTM and GA4 and/or integrate TRUENDO via GTM.

<div class="sd-callout" data-callout-type="alert">Before proceeding please <strong>remove/deactivate any existing scripts/plugins you may have previously used to integrate TRUENDO</strong> on your website. Google Tag manager will do it automatically once the procedure below is completed.</div>

<br />