---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: 'Geo-Control (Duplicate)'
id: 7BH-U2OQ-FU6-LW8
slug: geo-control-duplicate
isVisible: true
lastUpdated: '2024-09-23 12:15:47'
---
# SmartGeo(geo-Control)

TRUENDO allows users to choose whether the consent banner is displayed to visitors from European Union nations or to everyone who visits a website by use of a simple toggle.

This setting is found in the Banner section of the navigation menu under **Advanced**.

<figure><img src="https://app.snazzydocs.com/storage/users/hEfI2V55cVTdM5ty/docs/G2IomO8914MUXZZJ/images/INoZ7ELhR7HGDFYfCkvi.png"></figure>

<br />