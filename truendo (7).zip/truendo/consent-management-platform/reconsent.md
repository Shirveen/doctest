---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: Reconsent
id: EH8-M4ZY-8WS-9S8
slug: reconsent
isVisible: true
lastUpdated: '2024-08-19 10:12:59'
---
Reconsent

<br />

As a website owner or administrator you may occassionally make changes to services or tools that you use on your website. Some of these may affect the privacy of you visitors. so much so that you may want to request consent from your visitors again.<br />
<br />
Remember that a privacy subject's consent decision is normally valid for a period of one year in TRUENDO in line with GDPR requirements. So normally they would not be met with the consent request banner again during this period.<br />
<br />
Now you can manually initiate a consent request for all visitors from within the TRUENDO console using the Reconsent function.<br />
<br />
You must be logged in to TRUENDo and have the relevant Organization and Website selected

<br />

Then click Settings in the left menu panel

<br />

Scroll to the Reconsent section and click the box. You will be met with a dialog box asking you to save and instructing you to publish to initiate the reconsent.

<br />

No click Publish in the top right of the screen. Any visitor will now be met with the consent request banner regardless of previous consent state. Please note they will be treated as new Unique Visitors.