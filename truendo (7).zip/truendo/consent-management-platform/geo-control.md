---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: Geo-Control
id: DPY-KF52-922-E3T
slug: geo-control
isVisible: true
lastUpdated: '2024-08-19 12:47:35'
---
# SmartGeo(geo-Control)

TRUENDO allows users to choose whether the consent banner is displayed to visitors from European Union nations or to everyone who visits a website by use of a simple toggle.

This setting is found in the Banner section of the navigation menu under **Advanced**.

<figure><img src="https://app.snazzydocs.com/storage/users/hEfI2V55cVTdM5ty/docs/G2IomO8914MUXZZJ/images/INoZ7ELhR7HGDFYfCkvi.png"></figure>

<br />