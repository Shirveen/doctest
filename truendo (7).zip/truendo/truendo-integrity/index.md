---
# snazzyDocs - DO NOT REMOVE OR EDIT BELOW THIS LINE
title: Index
id: 6V1-7UGW-8BN-DEG
slug: index
isVisible: true
lastUpdated: '2024-08-30 12:39:56'
---
# TRUENDO Integrity

TRUENDO Integrity is a powerful tool that lets website owners and administrators know whether their site is violating data privacy and consent regulations.

It does this by scanning your website and checking for services that are running without being consented to.<br />
<br />
Please note this only applies to non necessary services/cookies<br />
<br />
TRUENDO performs automatic monthly scans on all domains but Premium subscribers may perform these scans on demand whenever they choose.<br />
<br />
To initiate a manual TRUENDO Integrity scan

<br />

1.  Make sure you are logged in to your TRUENDO Premium account and that you have selected the desired organization and website.
2.  Click on Settings in the panel on the left.
3.  In the main window scroll until you see the TRUENDO Integrity subsection and hover over the 'Start Compliance Test' box until you see the blue check appear.
4.  Then click Start Test

<br />